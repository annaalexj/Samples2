package com.myapps.b.set.data;

public interface BaseMarker {

}
