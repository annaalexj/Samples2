package com.myapps.b.set;


public interface ActivityListener {
	void onFinish(BaseAppData data);
	void onCancel(BaseAppData data);
}
