package com.myapps.b.set.viewholders;

import android.widget.LinearLayout;
import android.widget.TextView;

public class GroupViewHolder
{
	public TextView txtGroupHeader;
	public LinearLayout  lyGroupHeader ;
	public int position = -1;
}